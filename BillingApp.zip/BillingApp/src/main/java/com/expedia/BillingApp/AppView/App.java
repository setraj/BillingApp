package com.expedia.BillingApp.AppView;
import java.util.ArrayList;
import java.util.List;


import com.expedia.BillingApp.facadeLayer.BillingAppHelper;
import com.expedia.BillingApp.model.ItemDetail;

public class App 
{
	public static BillingAppHelper billingHelper=new BillingAppHelper();
    public static void main( String[] args )
    {        
    	generateInvoice();    	    	
    }
    
    private static void generateInvoice() {
		
		List<ItemDetail> itemList=new ArrayList<ItemDetail>();
		
		itemList.add(billingHelper.addItemtoInvoice("bottle of wine",20.00,1,"NM"));
		itemList.add(billingHelper.addItemtoInvoice("Chair",30.00,2,"NM"));
		itemList.add(billingHelper.addItemtoInvoice("Cipladine",20.00,1,"M"));
		itemList.add(billingHelper.addItemtoInvoice("Book",200.00,1,"NM"));
		showInvoice(itemList);
	}

	private static void showInvoice(List<ItemDetail> itemList) {
		billingHelper.showInvoice(itemList);	
	}
}
