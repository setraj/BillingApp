package com.expedia.BillingApp.model;

public class ItemDetail {
	
	private String itemId;
	private String name;
	private double price;
	private double finalPrice;
	private long quantity;
	private String ItemType;
	
	
	public void GoodDetail(long markId, String itemId, String name, double price, double finalPrice, long quantity,
			String ItemType) {		
		this.itemId = itemId;
		this.name = name;
		this.price = price;
		this.finalPrice = finalPrice;
		this.quantity = quantity;
		this.ItemType = ItemType;
	}	

	public String getItemId() {
		return itemId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public String getItemType() {
		return ItemType;
	}

	public void setItemType(String ItemType) {
		this.ItemType = ItemType;
	}

	public double getFinalPrice() {
		return finalPrice;
	}

	public void setFinalPrice(double finalPrice) {
		this.finalPrice = finalPrice;
	}
}
