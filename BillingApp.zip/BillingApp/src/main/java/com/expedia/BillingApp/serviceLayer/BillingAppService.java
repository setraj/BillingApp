package com.expedia.BillingApp.serviceLayer;

import java.util.ArrayList;
import java.util.List;

import com.expedia.BillingApp.model.Invoice;
import com.expedia.BillingApp.model.ItemDetail;

public class BillingAppService {
		
	List<ItemDetail> itemDetails= new ArrayList<ItemDetail>();
	List<Invoice> invoices=new ArrayList<Invoice>();

	public ItemDetail addItemtoInvoice(String itemName, double itemPrice, long itemQuantity, String itemType) {
		
		ItemDetail itemDetail=new ItemDetail();
		itemDetail.setName(itemName);
		itemDetail.setPrice(itemPrice);
		itemDetail.setItemType(itemType);
		itemDetail.setQuantity(itemQuantity);	
		itemDetails.add(itemDetail);
		return itemDetail;
	}

	public void showInvoice(List<ItemDetail> itemList) {
		Invoice invoice =processInvoice(itemList);
		invoices.add(invoice);
		printInvoice(invoice);
	}

	private void printInvoice(Invoice invoice) {
		System.out.println("Invoice Id: "+invoice.getInvoiceId());
		for(ItemDetail itemDetail:invoice.getItemDetail()) {
			System.out.println(itemDetail.getQuantity() + " "+ itemDetail.getName() + ": "+ itemDetail.getFinalPrice());
		}
		System.out.println("SalesTax: "+invoice.getSalesTax());
		System.out.println("Total: "+invoice.getTotalAmount());
	}

	private Invoice processInvoice(List<ItemDetail> itemList) {
		Invoice invoice=new Invoice();
		double totalSalesTax=0.0;
		double totalAmount=0.0;
		invoice.setId(invoice.getId()+1);
		for(ItemDetail itemDetail:itemList) {
			if(itemDetail.getItemType().equalsIgnoreCase("m")) {
				itemDetail.setFinalPrice(itemDetail.getPrice()*itemDetail.getQuantity());
			}
			else
			{
				double taxPayble=itemDetail.getPrice()/5;
				itemDetail.setFinalPrice((itemDetail.getPrice()+taxPayble)*itemDetail.getQuantity());
				totalSalesTax+=taxPayble*itemDetail.getQuantity();
			}
			totalAmount+=itemDetail.getFinalPrice();
		}
		invoice.setItemDetail(itemList);
		invoice.setSalesTax(totalSalesTax);
		invoice.setTotalAmount(totalAmount);
		return invoice;
	}

	public void getAllInvoices() {
		for(Invoice invoice:invoices) {
			printInvoice(invoice);
		}
		
	}
}
