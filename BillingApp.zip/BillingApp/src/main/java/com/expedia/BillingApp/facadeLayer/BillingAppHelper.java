package com.expedia.BillingApp.facadeLayer;
import com.expedia.BillingApp.model.ItemDetail;
import com.expedia.BillingApp.serviceLayer.BillingAppService;
import java.util.List;

public class BillingAppHelper {
		
		public static BillingAppService billingservice  = new BillingAppService();
		
		public ItemDetail addItemtoInvoice(String itemName, double itemPrice, long itemQuantity, String itemType) {
			return billingservice.addItemtoInvoice(itemName,itemPrice,itemQuantity,itemType);
			
		}
		public void showInvoice(List<ItemDetail> goodsList) {
			billingservice.showInvoice(goodsList);
			
		}
		public void getAllInvoices() {
			billingservice.getAllInvoices();
			
		}
}
