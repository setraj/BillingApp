package com.expedia.BillingApp.model;

import java.util.List;

public class Invoice {

	private String invoiceId;
	private long id=100;
	private List<ItemDetail> itemDetail;
	private double salesTax;
	private double totalAmount;
	
	public String getInvoiceId() {
		return invoiceId;
	}
	public double getSalesTax() {
		return salesTax;
	}
	public void setSalesTax(double salesTax) {
		this.salesTax = salesTax;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount2) {
		this.totalAmount = totalAmount2;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
		this.invoiceId="Invoice_"+id;
	}
	public List<ItemDetail> getItemDetail() {
		return itemDetail;
	}
	public void setItemDetail(List<ItemDetail> itemDetail) {
		this.itemDetail = itemDetail;
	}

}
